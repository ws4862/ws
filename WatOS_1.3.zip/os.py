# Wat OS 1.3
import os, sys, time, json, hashlib, secrets, zipfile, subprocess, webbrowser, shutil, tempfile
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle, Rectangle, Line
from kivy.metrics import dp
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView

WOS_VERSION = "1.3.0"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SYSTEM_DIR = os.path.join(BASE_DIR, "System")
APPS_DIR = os.path.join(BASE_DIR, "Apps")
DATA_DIR = os.path.join(BASE_DIR, "Data")
UPDATE_DIR = os.path.join(SYSTEM_DIR, "Updates")
CONFIG_FILE = os.path.join(SYSTEM_DIR, "system.json")
SIGNAL_FILE = os.path.join(SYSTEM_DIR, "apps_changed.signal")
PENDING_FILE = os.path.join(UPDATE_DIR, "pending.json")
os.makedirs(SYSTEM_DIR, exist_ok=True)
os.makedirs(APPS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPDATE_DIR, exist_ok=True)

BG=(0.015,0.02,0.04,1); PANEL=(0.035,0.055,0.09,1)
PANEL2=(0.055,0.08,0.13,1); CYAN=(0,0.85,1,1)
WHITE=(0.93,0.97,1,1); GRAY=(0.48,0.58,0.68,1)
RED=(1,0.18,0.35,1); GREEN=(0.15,1,0.65,1)

def load_json(path, default=None):
    try:
        with open(path,"r",encoding="utf-8") as f: return json.load(f)
    except Exception: return default

def save_json(path, data):
    tmp=path+".tmp"
    with open(tmp,"w",encoding="utf-8") as f: json.dump(data,f,indent=2,ensure_ascii=False)
    os.replace(tmp,path)

def hash_password(password, salt=None):
    salt=salt or secrets.token_hex(16)
    h=hashlib.pbkdf2_hmac("sha256",password.encode(),salt.encode(),120000).hex()
    return salt,h

def check_password(password,salt,stored):
    return hashlib.pbkdf2_hmac("sha256",password.encode(),salt.encode(),120000).hex()==stored

def version_tuple(v):
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except Exception:
        return (0,)

def touch_signal():
    try:
        with open(SIGNAL_FILE,"w",encoding="utf-8") as f:
            f.write(str(time.time()))
    except Exception: pass

class FuturisticButton(Button):
    def __init__(self,**kw):
        super().__init__(**kw)
        self.background_normal=""; self.background_down=""
        self.background_color=(0,0,0,0); self.color=WHITE
        self.font_size=dp(17)
        with self.canvas.before:
            Color(*PANEL2); self.rect=RoundedRectangle(pos=self.pos,size=self.size,radius=[dp(12)])
            Color(*CYAN); self.border=Line(rounded_rectangle=(0,0,0,0,dp(12)),width=0.8)
        self.bind(pos=self.sync,size=self.sync)
    def sync(self,*a):
        self.rect.pos=self.pos; self.rect.size=self.size
        self.border.rounded_rectangle=(self.x,self.y,self.width,self.height,dp(12))

class FuturisticPanel(BoxLayout):
    def __init__(self,**kw):
        super().__init__(**kw)
        with self.canvas.before:
            Color(*BG); self.bg=Rectangle(pos=self.pos,size=self.size)
        self.bind(pos=self.sync,size=self.sync)
    def sync(self,*a): self.bg.pos=self.pos; self.bg.size=self.size

class Splash(Screen):
    def __init__(self,**kw):
        super().__init__(**kw)
        l=FuturisticPanel(orientation="vertical",padding=dp(40),spacing=dp(12))
        l.add_widget(Label(text="WAT",font_size=dp(76),bold=True,color=CYAN))
        l.add_widget(Label(text="WAT OS",font_size=dp(34),bold=True,color=WHITE))
        l.add_widget(Label(text="SYSTEM CORE 1.3",font_size=dp(15),color=GRAY))
        self.p=ProgressBar(max=100,value=0,size_hint_y=None,height=dp(7)); l.add_widget(self.p)
        self.status=Label(text="Iniciando módulos...",font_size=dp(15),color=GRAY); l.add_widget(self.status)
        self.add_widget(l); Clock.schedule_interval(self.tick,.025)
    def tick(self,dt):
        self.p.value+=1
        if self.p.value>=100:
            Clock.unschedule(self.tick); App.get_running_app().finish_boot()

class Setup(Screen):
    def __init__(self,**kw):
        super().__init__(**kw)
        l=FuturisticPanel(orientation="vertical",padding=dp(35),spacing=dp(14))
        l.add_widget(Label(text="CONFIGURAÇÃO INICIAL",font_size=dp(28),bold=True,color=CYAN,size_hint_y=None,height=dp(60)))
        l.add_widget(Label(text="Crie seu usuário do Wat OS.",font_size=dp(16),color=GRAY,size_hint_y=None,height=dp(35)))
        self.name=TextInput(hint_text="Nome",multiline=False,font_size=dp(20),size_hint_y=None,height=dp(58))
        self.pw=TextInput(hint_text="Senha",password=True,multiline=False,font_size=dp(20),size_hint_y=None,height=dp(58))
        self.pw2=TextInput(hint_text="Confirme a senha",password=True,multiline=False,font_size=dp(20),size_hint_y=None,height=dp(58))
        l.add_widget(self.name); l.add_widget(self.pw); l.add_widget(self.pw2)
        self.err=Label(text="",color=RED,font_size=dp(14)); l.add_widget(self.err)
        b=FuturisticButton(text="CRIAR USUÁRIO",size_hint_y=None,height=dp(62)); b.bind(on_release=self.save); l.add_widget(b)
        self.add_widget(l)
    def save(self,*a):
        n=self.name.text.strip(); p=self.pw.text
        if not n: self.err.text="Informe um nome."; return
        if len(p)<4: self.err.text="A senha precisa ter pelo menos 4 caracteres."; return
        if p!=self.pw2.text: self.err.text="As senhas não coincidem."; return
        salt,h=hash_password(p)
        save_json(CONFIG_FILE,{"wat_os":WOS_VERSION,"configured":True,"user":{"name":n,"salt":salt,"hash":h}})
        App.get_running_app().home()

class Lock(Screen):
    def __init__(self,**kw):
        super().__init__(**kw)
        l=FuturisticPanel(orientation="vertical",padding=dp(35),spacing=dp(18))
        self.clock=Label(text="",font_size=dp(54),bold=True,color=WHITE,size_hint_y=None,height=dp(80))
        self.user=Label(text="",font_size=dp(23),color=CYAN,size_hint_y=None,height=dp(45))
        self.pw=TextInput(hint_text="Senha",password=True,multiline=False,font_size=dp(21),size_hint_y=None,height=dp(62))
        self.err=Label(text="",color=RED,size_hint_y=None,height=dp(35))
        b=FuturisticButton(text="DESBLOQUEAR",size_hint_y=None,height=dp(62)); b.bind(on_release=self.unlock)
        l.add_widget(self.clock); l.add_widget(self.user); l.add_widget(self.pw); l.add_widget(self.err); l.add_widget(b)
        self.add_widget(l); Clock.schedule_interval(self.time,1)
    def on_pre_enter(self,*a):
        c=load_json(CONFIG_FILE,{})
        self.user.text=c.get("user",{}).get("name","")
        self.pw.text=""; self.err.text=""
    def time(self,dt): self.clock.text=time.strftime("%H:%M")
    def unlock(self,*a):
        c=load_json(CONFIG_FILE)
        u=c.get("user",{})
        if u and check_password(self.pw.text,u["salt"],u["hash"]): App.get_running_app().home()
        else: self.err.text="Senha incorreta."

class Home(Screen):
    def __init__(self,**kw):
        super().__init__(**kw)
        self.rootbox=FuturisticPanel(orientation="vertical")
        top=BoxLayout(size_hint_y=None,height=dp(76),padding=dp(14),spacing=dp(12))
        self.time_label=Label(text="",font_size=dp(24),color=WHITE)
        top.add_widget(self.time_label)
        top.add_widget(Label(text="WAT OS",font_size=dp(25),bold=True,color=CYAN))
        lock=FuturisticButton(text="🔒",size_hint_x=None,width=dp(65)); lock.bind(on_release=lambda *_:App.get_running_app().lock())
        top.add_widget(lock); self.rootbox.add_widget(top)
        self.grid=GridLayout(cols=4,spacing=dp(15),padding=dp(18),size_hint_y=None)
        self.grid.bind(minimum_height=self.grid.setter("height"))
        s=ScrollView(); s.add_widget(self.grid); self.rootbox.add_widget(s)
        self.add_widget(self.rootbox)
        Clock.schedule_interval(self.clock_tick,1)
        Clock.schedule_interval(self.watch_signal,1)
        self.last_signal=""
    def on_pre_enter(self,*a): self.refresh()
    def clock_tick(self,dt): self.time_label.text=time.strftime("%H:%M")
    def watch_signal(self,dt):
        try:
            if os.path.exists(SIGNAL_FILE):
                sig=open(SIGNAL_FILE,encoding="utf-8").read()
                if sig!=self.last_signal:
                    self.last_signal=sig; self.refresh()
        except Exception: pass
    def refresh(self,*a):
        self.grid.clear_widgets()
        ws=os.path.join(APPS_DIR,"Ws.py")
        if os.path.exists(ws): self.add_app("Ws","Wat Store",ws)
        up=os.path.join(APPS_DIR,"up.py")
        if os.path.exists(up): self.add_app("Update","Upgrade Wos",up)
        for fn in sorted(os.listdir(APPS_DIR),key=str.lower):
            if fn.lower().endswith(".wata"):
                path=os.path.join(APPS_DIR,fn); data=read_wata(path)
                if data: self.add_app(data["name"],"v"+data["version"],path)
    def add_app(self,name,sub,path):
        box=BoxLayout(orientation="vertical",size_hint_y=None,height=dp(130),padding=dp(5))
        b=FuturisticButton(text=name,font_size=dp(18),size_hint_y=None,height=dp(75))
        b.bind(on_release=lambda *_:self.launch(path)); box.add_widget(b)
        box.add_widget(Label(text=sub,color=GRAY,font_size=dp(12))); self.grid.add_widget(box)
    def launch(self,path):
        if path.endswith(".py"): subprocess.Popen([sys.executable,path],cwd=BASE_DIR)
        elif path.endswith(".wata"): launch_wata(path)
    def on_enter(self): self.refresh()

def read_wata(path):
    try:
        with zipfile.ZipFile(path) as z:
            if "config.txt" not in z.namelist(): return None
            t=z.read("config.txt").decode("utf-8")
        def tag(n):
            a="<"+n+">"; b="</"+n+">"
            return t.split(a,1)[1].split(b,1)[0].strip() if a in t and b in t else ""
        return {"name":tag("name"),"version":tag("version"),"base":tag("base"),"ico":tag("ico"),"creator":tag("creator")}
    except Exception as e:
        print("WATA inválido:",path,e); return None

def launch_wata(path):
    data=read_wata(path)
    if not data: return
    appdir=os.path.join(DATA_DIR,"Apps",os.path.splitext(os.path.basename(path))[0])
    os.makedirs(appdir,exist_ok=True)
    try:
        with zipfile.ZipFile(path) as z: z.extractall(appdir)
        base=os.path.abspath(os.path.join(appdir,data["base"]))
        if not os.path.exists(base): return
        if base.lower().endswith((".html",".htm")): webbrowser.open("file://"+base)
        elif base.lower().endswith(".py"): subprocess.Popen([sys.executable,base],cwd=appdir)
    except Exception as e: print("Erro WATA:",e)

class WatOS(App):
    def build(self):
        Window.clearcolor=BG
        sm=ScreenManager(transition=FadeTransition(duration=.2))
        sm.add_widget(Splash(name="splash")); sm.add_widget(Setup(name="setup")); sm.add_widget(Lock(name="lock"))
        self.home_screen=Home(name="home"); sm.add_widget(self.home_screen); return sm
    def finish_boot(self):
        pending=load_json(PENDING_FILE)
        if pending and pending.get("ready"):
            print("Atualização pendente. Será aplicada pelo próximo processo de boot.")
        c=load_json(CONFIG_FILE)
        self.root.current="setup" if not c or not c.get("configured") else "lock"
    def home(self): self.root.current="home"; self.home_screen.refresh()
    def lock(self): self.root.current="lock"

if __name__=="__main__": WatOS().run()
