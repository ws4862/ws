Wat OS 1.3
============

Estrutura:
os.py                 núcleo/interface do sistema
start_watos.py        inicializador; aplica atualizações pendentes antes do boot
Apps/Ws.py            Wat Store de fábrica
Apps/up.py            atualizador de fábrica
Apps/*.wata           aplicativos instalados
System/system.json    configuração do usuário
System/Updates/       arquivos de atualização pendentes
Data/Apps/            conteúdo extraído dos .wata
Logs/                 reservado para logs futuros

Atualização:
1. Apps/up.py baixa version.txt.
2. Espera exatamente V:Wos:X.Y.Z na primeira linha.
3. Se a versão remota for maior, baixa os.py e ws.py.
4. Os arquivos ficam em System/Updates.
5. No próximo boot, start_watos.py aplica os arquivos e inicia os.py.

Observação:
O updater não substitui os.py enquanto ele está rodando. Isso evita deixar o sistema em estado parcial.
