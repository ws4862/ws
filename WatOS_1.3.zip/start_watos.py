#!/usr/bin/env python3
# start_watos.py - inicializador do Wat OS 1.3
import os, json, shutil, subprocess, sys
BASE=os.path.dirname(os.path.abspath(__file__))
UP=os.path.join(BASE,"System","Updates")
P=os.path.join(UP,"pending.json")
if os.path.exists(P):
    try:
        with open(P,encoding="utf-8") as f: d=json.load(f)
        if d.get("ready"):
            osn=d.get("os_new"); wsn=d.get("ws_new")
            if osn and os.path.exists(osn): shutil.copy2(osn,os.path.join(BASE,"os.py"))
            if wsn and os.path.exists(wsn): shutil.copy2(wsn,os.path.join(BASE,"Apps","Ws.py"))
            for x in (osn,wsn):
                if x and os.path.exists(x): os.remove(x)
            os.remove(P)
    except Exception as e:
        print("Falha aplicando atualização:",e)
subprocess.run([sys.executable,os.path.join(BASE,"os.py")])
