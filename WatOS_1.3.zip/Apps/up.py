# up.py - Wat OS Updater 1.3
import os, sys, json, tempfile, urllib.request, shutil, hashlib
from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle

CURRENT_VERSION="1.3.0"
VERSION_URL="https://ws4862.github.io/ws/version.txt"
OS_URL="https://ws4862.github.io/ws/os.py"
WS_URL="https://ws4862.github.io/ws/ws.py"
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
SYSTEM_DIR=os.path.join(BASE_DIR,"System")
UPDATE_DIR=os.path.join(SYSTEM_DIR,"Updates")
PENDING=os.path.join(UPDATE_DIR,"pending.json")
os.makedirs(UPDATE_DIR,exist_ok=True)

BG=(.015,.02,.04,1); CYAN=(0,.85,1,1); WHITE=(.93,.97,1,1); GRAY=(.48,.58,.68,1); RED=(1,.2,.3,1); GREEN=(.2,1,.65,1)

def vt(v):
    try:return tuple(int(x) for x in v.strip().split("."))
    except:return (0,)

def download(url,path):
    req=urllib.request.Request(url,headers={"User-Agent":"WatOS-Updater/1.3"})
    with urllib.request.urlopen(req,timeout=60) as r:
        data=r.read()
    if not data: raise RuntimeError("Arquivo vazio recebido.")
    with open(path,"wb") as f:f.write(data)

class Up(App):
    def build(self):
        Window.clearcolor=BG
        l=BoxLayout(orientation="vertical",padding=dp(45),spacing=dp(18))
        with l.canvas.before:
            Color(*BG); self.bg=Rectangle(pos=l.pos,size=l.size)
        l.bind(pos=lambda *_:self.sync(),size=lambda *_:self.sync())
        l.add_widget(Label(text="UPGRADE WOS",font_size=dp(36),bold=True,color=CYAN,size_hint_y=None,height=dp(70)))
        self.info=Label(text=f"Versão instalada: {CURRENT_VERSION}",font_size=dp(17),color=GRAY)
        l.add_widget(self.info)
        self.button=Button(text="VERIFICAR",font_size=dp(20),size_hint_y=None,height=dp(65),background_normal="",background_color=(.05,.1,.16,1),color=WHITE)
        self.button.bind(on_release=self.check); l.add_widget(self.button)
        self.add_widget(l); return l
    def sync(self):
        self.bg.pos=self.root.pos; self.bg.size=self.root.size
    def check(self,*a):
        self.button.disabled=True; self.info.text="Verificando versão..."
        try:
            fd,path=tempfile.mkstemp(); os.close(fd)
            download(VERSION_URL,path)
            with open(path,"r",encoding="utf-8") as f: line=f.readline().strip()
            os.unlink(path)
            # formato esperado: V:Wos:1.2.3
            parts=line.split(":")
            if len(parts)!=3 or parts[0]!="V" or parts[1]!="Wos": raise ValueError("version.txt inválido.")
            remote=parts[2].strip()
            if vt(remote)<=vt(CURRENT_VERSION):
                self.info.text=f"Você já está atualizado. Versão: {CURRENT_VERSION}"
                self.button.disabled=False; return
            self.info.text=f"Nova versão encontrada: {remote}\nBaixando atualização..."
            os_path=os.path.join(UPDATE_DIR,"os.py.new")
            ws_path=os.path.join(UPDATE_DIR,"Ws.py.new")
            download(OS_URL,os_path); download(WS_URL,ws_path)
            # arquivos baixados são mantidos para o próximo boot; não substituímos código em execução.
            with open(PENDING,"w",encoding="utf-8") as f:
                json.dump({"ready":True,"version":remote,"os_new":os_path,"ws_new":ws_path},f,indent=2)
            self.info.text=f"Atualização {remote} baixada.\nReinicie o Wat OS para aplicar."
            self.button.text="ATUALIZAÇÃO PRONTA"; self.button.disabled=True
        except Exception as e:
            self.info.text="Não foi possível atualizar:\n"+str(e); self.button.disabled=False

if __name__=="__main__": Up().run()
